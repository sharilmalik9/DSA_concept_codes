package com.company;
import java.util.Arrays;
import java.util.Scanner;

public class rotate_array {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int[] nums={1,2,3,4,5,6,7};
        int k=sc.nextInt();
        int idx=0;
        int[] ans= new int[nums.length];
        for(int i=nums.length-k;i<nums.length;i++){
            ans[idx]=nums[i];
            idx++;

        }



        for(int i=0;i<nums.length-k;i++){
            ans[idx]=nums[i];
            idx++;
        }
        nums=ans;
        System.out.println(Arrays.toString(nums));

    }

}
