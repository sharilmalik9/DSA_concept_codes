package com.company;
// error

public class Peak_Index_in_a_Mountain_Array {
    static int mountainIndex(int[] arr){
        int start=0;
        int end=arr.length-1;

        while(start<=end){
            int mid=(start+end)/2;

            if(arr[mid-1]>arr[mid]&& arr[mid+1]<arr[mid]){
                end=mid-1;

            }
             if(arr[mid-1]<arr[mid] && arr[mid+1]>arr[mid]){
                start=mid+1;

                
            }
            else{
                 System.out.println("here ");

                return mid;

            }
        }
        return -1;

    }
    // finding greatest element index
    static int peak(int[] arr){
        int n=0;
        for(int i=0;i<arr.length;i++){
            if(arr[i]>arr[n]){
                n=i;
            }
        }
        return n ;
    }
    public static void main(String[] args) {
        int[] arr= {0,10,5,2};
        System.out.println(mountainIndex(arr));
        System.out.println(peak(arr));

    }
}
