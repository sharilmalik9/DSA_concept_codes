package com.company;
import java.util.*;

public class longest_consecutive_sequence {
    public static void main(String[] args) {
        Map<Integer,Integer> sh= new HashMap<>();
        int[] nums={1,3,2,4,7,6};

        for(int i=0;i<nums.length;i++) {
            if (!sh.containsKey(nums[i])) {
                sh.put(nums[i], 1);

            }
        }
        int max=1;
        int curr=1;
        for(int i:nums){
            if(!sh.containsKey(i-1)) {
                int that = i;
                if (sh.containsKey(i + 1)) {
                    System.out.println("here");
                    while (sh.containsKey(that + 1)) {
                        that++;
                        curr++;

                    }
                    if (curr > max) {
                        max = curr;
                    }
                    curr=1;

                }
            }

        }
        System.out.println(max);

    }


}
