package com.company;

public class chp3_final {
    public static void main(String[] args) {
        String name;
        name = new String("hello");
        System.out.println(name);
        int value= 5;
        System.out.printf("the vaalue is %d",value);
    }
}
