package com.company;
import java.util.*;

public class pascal_triangle {

}
