package com.company;
import java.util.*;


public class Best_Time_to_Buy_and_Sell_Stock {
    static int besttime(int[] arr) {
        int minElement =arr[0];
        int maxDifference = 0;
        for (int i = 1; i < arr.length; i++) {
            minElement=Math.min(arr[i],minElement);
            int curr_difference=arr[i]-minElement;
            maxDifference=Math.max(maxDifference,curr_difference);
        }
        return maxDifference;
    }


    public static void main(String[] args){
        int[] arr={2,1};
        System.out.println(besttime(arr));
    }
}
