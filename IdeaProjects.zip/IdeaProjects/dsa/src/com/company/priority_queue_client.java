package com.company;
import java.util.*;


public class priority_queue_client {
    public static void main(String[] args) {
        PriorityQueue<Integer> obj = new PriorityQueue<>();


    }

}
