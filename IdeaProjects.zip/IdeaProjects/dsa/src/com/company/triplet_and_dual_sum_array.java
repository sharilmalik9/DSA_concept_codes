package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class triplet_and_dual_sum_array {
    static List<List<Integer>> dual_sum(int[] arr,int target,int start,int end ){
        Arrays.sort(arr);
        List<List<Integer>> ans = new ArrayList<List<Integer>>();

        while(start<end){
            int t= arr[start]+arr[end];
            if(t>target){
                end--;
            }
            else if(t<target){
                start++;
            }
            else{

                List<Integer> hey= new ArrayList<>();
                hey.add(arr[start]);
                hey.add(arr[end]);
                ans.add(hey);
                start++;
                end--;
                // direct way to add
             //     ans.add(Arrays.asList(start,end));

            }
        }
        return ans;

    }
    static List<List<Integer>> triplet_sum(int[] arr, int target){
        List<List<Integer>> ans = new ArrayList<List<Integer>>();

        for(int i=0;i<arr.length-2;i++){
            int left = target-arr[i];
            List<List<Integer>> ans1 = dual_sum(arr,left,i+1,arr.length-1);
            for(int j=0;j<ans1.size();j++){
                ans1.get(j).add(0,arr[i]);
                ans.add(ans1.get(j));
            }
        }
        return ans;
    }
    public static void main(String[] args) {
        // return indexes
        int[] arr = {1,2,3,4,5};
       //System.out.println(dual_sum(arr,5,1,arr.length-1));
        System.out.println(triplet_sum(arr,6));

    }

}
