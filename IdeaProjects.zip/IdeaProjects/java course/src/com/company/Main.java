package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner  a = new Scanner(System.in);

        System.out.println("enter no ");

        System.out.println(a.hasNextInt());


    }
}
