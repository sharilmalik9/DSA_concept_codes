package com.company;
import java.util.Arrays;
import java.util.Scanner;
public class Squares_of_a_Sorted_Array {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int no=sc.nextInt();
        int[] arr=new int[no];

        for(int i=0;i<no;i++){
            int value=sc.nextInt();
            arr[i]=value;


        }
        for(int i=0;i<no;i++){
            arr[i]*=arr[i];

        }
        for (int i =0;i<no;i++){

            for(int j =0; j<no-i-1;j++) {
                if (arr[j + 1] < arr[j]) {
                    int element=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=element;

                }
            }

        }
        for (int i:arr) {


            System.out.print(i +" ");
        }

        // squares of a no using o(n) time complexity
        // logic
        // create 2 sorted arays one of negative no and other of positive - o(n)
        // do merge 2 sorted arrays
        // and then square and add them
        int[] arr1={-4,-2,-1,0,4,6,7,9};
        int count=0;
        for(int i=0;i<arr1.length;i++){
            if(arr1[i]<0){
                count++;
            }
            else{
                break;
            }
        }
        int[] negative=new int[count];
        int idx=0;
        int idx1=0;
        int[] positive= new int[arr1.length-count];
        for(int i=0;i<arr1.length;i++){
            if(i<count){
                negative[idx]=-arr1[count-1-i];
                idx++;
            }
            else{
                positive[idx1]=arr1[i];
                idx1++;

            }

        }


    }
}
