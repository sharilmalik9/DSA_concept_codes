package com.company;


public class find_pivot_indx {
    static int pivotidx(int[] nums){
//        int ans =0;
//        int left=-1;
//        int right=nums.length-1;
//        int sumL=0;
//        int sumR=nums[right];
//        while(true){
//            if(sumR==sumL){
//                if(left+1!=right) {
//                    ans = left + 1;
//                    break;
//                }
//                else{
//                    ans=-1;
//                    break;
//                }
//            }
//            if(sumR>sumL){
//                left++;
//                sumL+=nums[left];
//            }
//            if(sumL>sumR){
//                right--;
//                sumR+=nums[right];
//            }
//            if(right==left||left> right){
//                ans=-1;
//                break;
//            }
//        }
//
//        return ans;
        int ans=0;
        int sum=0;
        int leftsum=0;
        int rightsum=0;

         for(int i:nums){
             sum+=i;
         }
         rightsum=sum-nums[0];
         for(int i=1;i<nums.length;i++){
             if(leftsum==rightsum){
                // System.out.println(i);
                 ans=i-1;
                 break;
             }

             leftsum+=nums[i-1];
             System.out.println(leftsum);
             rightsum-=nums[i];
             System.out.println(rightsum);
         }
         if(leftsum!=rightsum){
             if(ans==0){
                 ans=-1;
             }
         }
         else{
             if(ans==0&&(sum-nums[0]!=rightsum)){
                 ans=nums.length-1;
             }
         }

         return ans;
    }
    public static void main(String[] args) {
        int[] nums={-1,-1,0,1,0,-1};
        System.out.println( pivotidx(nums));

    }
}
