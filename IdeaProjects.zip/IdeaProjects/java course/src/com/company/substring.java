package com.company;
import java.util.Scanner;

public class substring {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        int upperlimit=sc.nextInt();
        int lowerlimit=sc.nextInt();
        System.out.println(str.substring(upperlimit,lowerlimit));



    }
}
