package com.company;
// find total profit possible such that no two stocks can be hold together

public class Best_Time_to_Buy_and_Sell_Stock_2 {
    static int buysell(int[] nums){
        int profit=0;
        for(int i=1;i<nums.length;i++){
            if(nums[i]>nums[i-1]){
                profit+=nums[i]-nums[i-1];
            }
        }
        return profit;
    }
    public static void main(String[] args) {
        int[] nums={9,8,7,6,5};
        System.out.println(buysell(nums));
    }
}
