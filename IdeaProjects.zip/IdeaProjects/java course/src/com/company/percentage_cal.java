package com.company;
import java.util.Scanner;

public class percentage_cal {
    public static void main(String[] args) {
        Scanner a= new Scanner(System.in);
        System.out.println("enter marks in english:");
        int english= a.nextInt();
        System.out.println("enter marks in maths: ");
        int maths= a.nextInt();
        System.out.println("enter marks in science:");
        int science =a.nextInt();
        System.out.println("enter marks in hindi:");
        int hindi =a.nextInt();
        System.out.println("enter marks in sst :");
        int sst = a.nextInt();
        int sum = english+sst+hindi+maths+science;
        System.out.println(sum);
        double percentage=((sum)/500.0)*100;
        System.out.println(percentage);


    }
}
