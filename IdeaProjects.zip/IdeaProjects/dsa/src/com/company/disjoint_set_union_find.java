package com.company;

public class disjoint_set_union_find {
    void disjoint_set(int n ){
        int[] p= new int[n];
    }
    int parent(int[] p,int x){
        if(p[x]==x){
            return x;
        }
        return parent(p,p[x]);
    }
    void union(int a,int b,int[] p){
        int x=parent(p,a);
        int y= parent(p,b);
        if(x==y){
            return;
        }
        p[x]=y;



    }

}
