package com.company;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Queue;

public class sliding_window_queue {

    static void slidingWindow(int[] arr, int k){

        Deque<Integer> que=new ArrayDeque<>();
        for(int i=0;i<k;i++){
            // for first window find the max
            while(!que.isEmpty()&&arr[i]>=arr[que.peek()]){


                que.removeLast();
            }
            que.addLast(i);
        }

        for(int i=k;i<arr.length;i++){


            // first element of queue in the ans of prev window
            System.out.println(arr[que.getFirst()]);
            // remove out of window elements
            while(!que.isEmpty()&&que.peek()<=i-k){
                que.removeFirst();
            }
            // keep the max element
            while(!que.isEmpty()&&arr[i]>arr[que.peek()]){
                que.removeLast();
            }
            que.addLast(i);


        }
        System.out.println(arr[que.peek()]);




    }
    static void slidingWindowMin(int[] arr, int k){

        Deque<Integer> que=new ArrayDeque<>();
        for(int i=0;i<k;i++){
            // for first window find the max
            while(!que.isEmpty()&&arr[i]<=arr[que.peek()]){


                que.removeFirst();
            }
            que.addLast(i);
        }

        for(int i=k;i<arr.length;i++){
          //  System.out.println(que);


            // first element of queue in the ans of prev window
            System.out.println(arr[que.getFirst()]);
            // remove out of window elements
            while(!que.isEmpty()&&que.peek()<=i-k){
                que.removeFirst();
            }
            // keep the max element
            while(!que.isEmpty()&&arr[i]<=arr[que.peek()]){
                que.removeLast();
            }
            que.addLast(i);


        }
     //  System.out.println(que);
        System.out.println(arr[que.getFirst()]);




    }


    public static void main(String[] args) {
        int[] arr= {5,4,3,2,1};
       slidingWindow(arr,3);
        slidingWindowMin(arr,3);
    }
}
