package com.company;
interface properties{
    void area();
    void perimeter();
    default void volume(){
        System.out.println("volume does not exist for this as it is a 2 d figure ");
    }


}
class circle1 implements properties{
    double radius;
    public void area(){
        double area= 3.14*radius*radius;
        System.out.println("area of circle"+ area);

    }
    public void perimeter(){
        double perimeter=2*3.14*radius;
        System.out.println("perimeter of cirle is "+ perimeter );
    }
}
public class package_creation {
    public static void main(String[] args) {
        circle1 sc= new circle1();
        sc.radius=23d;
        sc.area();
        sc.perimeter();

    }
}
class rectanle implements properties{
    double length;
    double breadth;
    public void area(){
        double area=length*breadth;
        System.out.println("area of rectangle "+ area);

    }
    public void perimeter(){
        double perimeter=2*(length+breadth);
        System.out.println("perimeter of rectangle is "+ perimeter );
    }
}
//class cube implements properties(){


