package com.company;
import java.lang.reflect.Array;
import java.util.Scanner;
class library{
    String urchoice;
    String[] books;
    String[] issuedbooks;
//    issuedbooks[]={"hello"};
    String[] fresharray;
    Scanner sc=new Scanner(System.in);


    public void AddBooks(String book,String...books){

        for(String i: books){
            System.out.println(i);
        }
    }
    public void issuebooks(){
        for(String i : books){
            System.out.println(i);
        }
//        System.out.println(books);
        System.out.println("choose the book you want from the given list ");
        String urchoice=sc.next();
        System.out.println("thanks for coming");
        String[] issuedbooks={urchoice};






    }
//    public void returnbook(){
//        System.out.println(issuedbooks);
//        System.out.println("select the book you want to return");
//        String toreturn=sc.next();
//        for(int a =0; a<issuedbooks.length ;a++){
//            if (issuedbooks[a]!=toreturn){
//            String[] fresharray={issuedbooks[a]};
//
//
//
//
//           }
//
//
//
//
//
//        }
//        System.out.println("now you have these books");
//        for(String i :fresharray){
//            System.out.println(i);
//        }
//
//
//        }


}

public class library_assigment {
    public static void main(String[] args) {
        library sc=new library();
        sc.AddBooks("gotta","hey","tata","get lost");
        sc.issuebooks();
//        sc.returnbook();

    }

}
