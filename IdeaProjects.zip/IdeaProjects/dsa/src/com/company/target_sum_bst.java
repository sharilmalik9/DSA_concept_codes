package com.company;
import java.util.*;

public class target_sum_bst {
    class Node{
        int data;
        Node left,right;
    }
    static boolean pairsum(Node root, int target){
        Set<Integer> help= new HashSet<>();
        return pairsumutil(root,target,help);

    }
    // LSR
    static boolean pairsumutil(Node root, int target,Set<Integer> help){
        if(root==null){
            return false;
        }
        // if both ans is there in left subtree return
        if(pairsumutil(root.left,target,help)==true){
            return true;
        }
        // for self
        // is from left we have such a value which can add upt root data and make target
        if(help.contains(target-root.data)){
            return true;
        }
        // for right subtree check
        help.add(root.data);
        return pairsumutil(root.right,target,help);
    }
}
