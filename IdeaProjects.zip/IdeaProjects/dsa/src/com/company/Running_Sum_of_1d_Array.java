package com.company;

import java.util.Arrays;

public class Running_Sum_of_1d_Array {

        static int[] runningsum(int[] nums){



            int sum=nums[0];
            for(int i=1;i<nums.length;i++){
               sum+=nums[i];
                nums[i]=sum;

            }
            return  nums;
        }

    public static void main(String[] args) {
            int[] arr={1,1,1,1,1};
        System.out.println(Arrays.toString(runningsum(arr)));

    }
}
