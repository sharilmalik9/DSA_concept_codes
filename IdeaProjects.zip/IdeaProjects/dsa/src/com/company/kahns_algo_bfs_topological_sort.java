package com.company;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class kahns_algo_bfs_topological_sort {
    static int[] kansBFSSort(List<List<Integer>> neigh,int v){
        int[] inDegree = new int[v];
        for(List<Integer> arr: neigh){
            for(int i:arr){
                inDegree[i]++;
            }
        }
      List<Integer> ans= new ArrayList<>();
        kansBFSSortUtil(neigh,v,inDegree,ans);
        int[] ansf=new int[v];
        for(int i=0;i<v;i++){
            ansf[i]=ans.remove(i);
        }
        return ansf;

    }
    static void kansBFSSortUtil(List<List<Integer>> neigh, int v,int[] indegree,List<Integer> ans){
        Queue<Integer> que= new ArrayDeque<>();
        for(int i=0;i<v;i++){
            if(indegree[i]==0){
                que.add(i);
            }
        }
        while(!que.isEmpty()){
            int curr= que.poll();
            ans.add(curr);
            for(int i:neigh.get(curr)){
                if(--indegree[i]==0){
                    que.add(i);
                }
            }
        }
    }
    public static void main(String[] args) {

    }
}
