package com.company;

import java.util.Arrays;
import java.util.Stack;

public class histogram_stacks {
    static int max_Histogram(int[] arr){

        int maxArea=0;
        int[] onleft=SmallestElementOnLeft(arr);
        int[] onright=smallestELementOnRight(arr);
        int idx=0;

        while(idx<arr.length){
            int area=(-onleft[idx]+onright[idx]-1)*arr[idx];
            maxArea= Math.max(area,maxArea);


            idx++;
        }
        return maxArea;

    }
    static int[] SmallestElementOnLeft(int[] arr) {
        int [] ans= new int[arr.length];
        Stack<Integer> anshelp= new Stack<>();

        int idx=0;
        for(int i=0;i<arr.length;i++) {
            while (!anshelp.empty() && arr[anshelp.peek()] >= arr[i]) {
                anshelp.pop();
            }
            if (anshelp.isEmpty()) {
                ans[idx] = -1;
                idx++;
            } else {
                ans[idx] = anshelp.peek();
                idx++;

            }
            anshelp.push(i);
        }

        return ans;
    }

    static int[] smallestELementOnRight(int[] arr){
        int [] ans= new int[arr.length];
        Stack<Integer> anshelp= new Stack<>();

        int idx=ans.length-1;
        for(int i=arr.length-1;i>=0;i--) {
            while (!anshelp.empty() && arr[anshelp.peek()] >= arr[i]) {
                anshelp.pop();
            }
            if (anshelp.isEmpty()) {
                ans[idx] = arr.length; // we can cosider that after array there can be an element smallest
                // only to be done to find area
                idx--;
            } else {

                ans[idx] = anshelp.peek();
                System.out.println(ans[idx]);
                idx--;

            }
            anshelp.push(i);
        }

        return ans;


    }

    public static void main(String[] args) {
        int[] arr={4,2,1,5,6,3,2,4,2};
        System.out.println(Arrays.toString(smallestELementOnRight(arr)));
        System.out.println(Arrays.toString(SmallestElementOnLeft(arr)));
        System.out.println(max_Histogram(arr));
    }
}

