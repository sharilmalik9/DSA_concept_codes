package com.company;

public class Capacity_To_Ship_Packages_Within_D_Days {
    static Boolean check(int[] arr,int mid,int days){
        int myday=1;
        int sum=0;
        for(int i=0;i<arr.length;i++){

            if(sum+arr[i]<=mid){

                sum+=arr[i];
            }
            else{
                sum=arr[i];
                myday++;
            }
        }
        if(myday<=days){
            return true;
        }
        else{
            return false;
        }
    }
    // here we find mid of the min - when no days= no of elements
    // max =one day= total sum
    // ans lies btw them only - so use binary search
    // mid element k about we check and find days if days are less than or equal to required days
    // we go less more less to find closest answer until the above condtition gets satisfied

    static int shipWithinDays(int[] weights,int days){
        int max=0;
        int min=0;
        int ans=0;
        for(int i=0;i<weights.length;i++){
            max+=weights[i];
            if(weights[i]>min){
                min=weights[i];
            }
        }
        while(min<=max){
            int mid=(max+min)/2;
            if(check(weights,mid,days)){
                ans=mid;
                max=mid-1;

            }
            else{
                min=mid+1;
            }
        }
        return ans;


    }
    public static void main(String[] args) {
        int[] arr={1,2,3,1,1,};
        System.out.println(shipWithinDays(arr,4));

    }
}
