package com.company;

public class chp7_practise {
    static void pattern1(int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < i + 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    static int sum(int n ) {
        if (n == 1) {
            return n;
        } else {
            return n + sum(n - 1);
        }
    }


    public static void main(String[] args) {
        pattern1(4);
        int c =sum(4);
        System.out.println(c);
    }



















}
