package com.company;
class hello extends Thread{
    public void Thread(){



            System.out.println("this is thread ");


    }
    public void hii(){
//        while(true) {


            System.out.println("this is trial ");
//        }
    }

        }
class hello1 extends Thread{
    public void run(){
        System.out.println("hello there ");
    }
    public void hii1(){
        System.out.println("this is nothing");
    }
}
public class threads {


    public static void main(String[] args) {
       threads1 t= new threads1();
       threads2 t1 = new threads2();
       Thread t2 = new Thread(t);
       Thread t3= new Thread(t1 );
       t2.start();
       t3.start();
        System.out.println(t2.getId());
        System.out.println(t3.getId());



    }

}
//this is method 2 to start Threading
//Using interface
class threads1 implements Runnable{
    public void run( ) {
//        while (true) {
            System.out.println("this is method 2 ");

//        }
    }
    public void Threads1(String name ){
//      super(name);

    }


        }
class threads2 implements Runnable{
    public void run() {
//        while (true) {
            System.out.println("this is method 1");
//        }
    }
}
// thread classes and methods
