package com.company;

import java.util.Arrays;
import java.util.Stack;

public class next_greater_on_right {
    static int[] NextGreaterOnRight(int[] temperatures){
        Stack<Integer> help= new Stack<>();
        if(temperatures.length==0){
            return null;
        }
        int[] ans= new int[temperatures.length];
        help.push(0);
        for(int i=1;i<temperatures.length;i++){
            while(!help.isEmpty()&&temperatures[help.peek()]<temperatures[i]){
                ans[help.peek()]=i-help.pop();
            }
            help.add(i);

        }
        while(!help.isEmpty()){
            ans[help.pop()]=0;
        }
        return ans;
    }


    public static void main(String[] args) {
        int[] arr={30,60,90};
        System.out.println(Arrays.toString(NextGreaterOnRight(arr)));

    }
}
