package com.company;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
// questions-
// find distance between source and destination

public class graph_BFS_Traversal {
    // pred stores the just before element of a vertices we just visited
    // dist - stores the distance of that vertice from the source
    static boolean BFSTraversal(ArrayList<ArrayList<Integer>> adj,int src,int dest,int v,int[] pred,int[] dist){
        Boolean[] visited = new Boolean[v+1];
        // could have been queue as well
        // just like we did level traversal
        LinkedList<Integer> queue=new LinkedList<>();
        for(int i=0;i<v;i++){
            visited[i]=false;
            pred[i]=-1;
            dist[i]=Integer.MAX_VALUE;

        }
        visited[src]=true;
        queue.add(src);
        dist[src]=0;
        while(!queue.isEmpty()){
            int curr= queue.remove();
           for(int i=0;i<adj.get(curr).size();i++){
               int neighbour=adj.get(curr).get(i);
               if(!visited[neighbour]){
                   //adding the element in queue just like level order traversal
                   // maintaining visited so that we dont end in finite loop as graph is bi directional
                   // size of curr means the linked/arraylist associated with that element
                   // it means that curr are connected to these many elements
                   visited[neighbour]=true;
                   pred[neighbour]=curr;
                   dist[neighbour]=dist[curr]+1;
                   queue.add(neighbour);
                   if(curr==dest){
                       return true;
                   }
               }
               // this returns if dest if found or not

           }
        }
        return false;
    }
    // ques = find how many connected nodes are there
    // in graph there can be elements which are not connected
    // for them visited will always be false

    public static void main(String[] args) {

    }
}
