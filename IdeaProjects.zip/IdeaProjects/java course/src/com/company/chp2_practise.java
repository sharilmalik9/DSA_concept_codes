package com.company;
import java.util.Scanner;

public class chp2_practise {
    public static void main(String[] args) {
      //  char p ='B';
        //p=(char)(p+8);
        //Scanner a = new Scanner(System.in);
        //System.out.println("enter the no ");
        //int b = a.nextInt();
        //System.out.println(9>b);


        //System.out.println(p);
        //p=(char)(p-8);
        //System.out.println(p);
        int x=7;
        int a = 7*49/7+35/7;
        System.out.println(a++);
        System.out.println(a);
        System.out.println(++a);
    }
}
