package com.company;

import java.util.Arrays;

//Given an array of integers nums and an integer target, return indices of the
// two numbers such that they add up to target.
//
//You may assume that each input would have exactly one solution, and you may not use the
// same element twice.
//You can return the answer in any order.
public class to_sum_in_array {
    static int[] twosum(int[] nums,int target){
        int[] arr= new int[nums.length];
        int idx=0;
        int[] ans= new int[2];
        int idx1=0;
        for(int i=0;i<nums.length;i++){

            arr[idx]=target-nums[i];

            idx++;
        }
        for(int i=0;i<arr.length;i++){

            int element=arr[i];
            for(int j=0;j<nums.length;j++){
                if(nums[j]==element){
                    if(i!=j) {

                        ans[0] = j;

                        ans[1] = i;
                    }
                    else{
                        continue;
                    }

                }

            }

        }
        return ans;



    }
    

    
    public static void main(String[] args) {
      int[] nums={3,3};
        System.out.println(Arrays.toString(twosum(nums,6)));
    }
}
