package com.company;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Scanner;

public class java_challenge2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int no=sc.nextInt();
        float[] array1=new float[no];


        for(int i=0;i<no;i++) {
            float no1 = sc.nextFloat();
            array1[i]=no1;
        }

           for(float q:array1) {

                   if (q <= 127.0 && q >= -128.0) {
                       System.out.println(q + " can be fitted in:");
                       System.out.println("* byte");
                       System.out.println("* short");
                       System.out.println("* int");
                       System.out.println("* long");

                   } else if (q <= (Math.pow(2, 16)) / 2 - 1 && q >= -((Math.pow(2, 16)) / 2)) {
                       System.out.println(q + " can be fitted in:");

                       System.out.println("* short");
                       System.out.println("* int");
                       System.out.println("* long");


                   } else if (q <= (Math.pow(2, 32)) / 2 - 1 && q >= -((Math.pow(2, 32)) / 2)) {
                       System.out.println((long) q + " can be fitted in:");

                       System.out.println("* int");
                       System.out.println("* long");
                   }
                   else if (q <= (Math.pow(2, 64)) / 2 - 1 && q >= -((Math.pow(2, 64)) / 2)) {
                       System.out.println((long) q + " can be fitted in:");

                       System.out.println("* long");

                   }


                   else {
//                       String str=Float.toString(q);
//                       int p=(int)q;


//                           BigInteger f = new BigInteger("q");
                       BigDecimal bb = BigDecimal.valueOf(q);

                           System.out.println(bb + " can't be fitted anywhere");


                   }
           }




    }

}
