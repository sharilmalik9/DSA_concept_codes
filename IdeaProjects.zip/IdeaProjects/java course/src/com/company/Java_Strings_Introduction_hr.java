package com.company;
import java.util.Scanner;


public class Java_Strings_Introduction_hr {
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        String str1 = sc.next();
        String str2 = sc.next();
        String sum = str1 + str2;
        int count = 0;
        for (int i = 0; i < sum.length(); i++) {
            if (sum.charAt(i) != ' ') {
                count += 1;
            }
        }

        System.out.println(count);

       int value=str1.compareTo(str2);
       if(value>0) {
           System.out.println("Yes");
       }
       else{
               System.out.println("No");
           }


        System.out.println();
       String fstr1=str1.substring(0,1);


       String str21=str1.replace(fstr1,fstr1.toUpperCase());
        String fstr2=str2.substring(0,1);


        String str22=str2.replace(fstr2,fstr2.toUpperCase());
        System.out.println(str21+" "+str22);



    }

}
