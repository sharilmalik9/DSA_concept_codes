package com.company;

import java.util.ArrayList;

public class graph_dfs_traversal {
    static ArrayList<Integer> dfs(int v ,ArrayList<ArrayList<Integer>> neigh){
        boolean[] visited= new boolean[v];
        for(int i=0;i<v;i++){
            visited[i]=false;
        }

        ArrayList<Integer> ans = new ArrayList<>();
        //for all connected graphs
      //  dfs1(0,neigh,ans,visited);
        // for not all connected graph
        for(int i=0;i<v;i++){
            if(!visited[i]){
                dfs1(i,neigh,ans,visited);
            }
        }
        return ans;
    }
    static void dfs1(int v,ArrayList<ArrayList<Integer>> neigh, ArrayList<Integer> ans, boolean[] visited){
        visited[v]=true; // true
        ans.add(v);
        for(Integer i:neigh.get(v)){
            if(!visited[i]){
                dfs1(i,neigh,ans,visited);

            }
        }

    }


    public static void main(String[] args) {


    }
}
