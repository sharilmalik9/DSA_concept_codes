package com.company;

import java.util.List;
import java.util.Stack;

public class topological_sorting {
    static int[] topologicalSort(List<List<Integer>> neigh,int v){
        boolean[] visited= new boolean[v];
        Stack<Integer> st= new Stack<>();
        for(int i=0;i<v;i++){
            if(!visited[i]){
                topologicalSortUtil(neigh,i,st,visited);
            }
        }
        int[] ans = new int[v];
        for(int i=0;i<v;i++){
            ans[i]=st.pop();
        }
        return ans;

    }
    static void topologicalSortUtil(List<List<Integer>> neigh, int v, Stack<Integer> st, boolean[] visited){
        visited[v] =true;
        for(int i : neigh.get(v)){
            if(!visited[v]){
                topologicalSortUtil(neigh,i,st,visited);
            }
        }
        st.push(v);
    }
}
