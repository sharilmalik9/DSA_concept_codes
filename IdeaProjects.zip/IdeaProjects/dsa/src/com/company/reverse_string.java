package com.company;

public class reverse_string {
    public static void main(String[] args) {
        String s="hello";
        int n =s.length();
        String str="";
        for(int i=0;i<n;i++){
           str+= s.charAt(n-i-1);

        }
        System.out.println(str);

    }

}
