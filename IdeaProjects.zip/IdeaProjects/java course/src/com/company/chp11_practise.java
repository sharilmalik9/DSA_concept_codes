//package com.company;
//abstract class pen{
//    abstract void refill();
//    abstract void write();
//}
//class fountainpen extends pen{
//    void refill(){
//        System.out.println("refilling your pen...");
//    }
//    void write(){
//        System.out.println("writing your name...");
//    }
//    public void hello(){
//        System.out.println("welcome to our pen store !");
//    }
//
//
//}
//interface tvremote{
//    void findchannel();
//
//
//}
//interface smarttvremote extends  tvremote{
//    void newchannel();
//    }
//
//class tv implements tvremote{
//
//}
//
//class monkey{
//    public void jump(){
//        System.out.println("jumping");
//    }
//    public void bite(){
//        System.out.println("eating ");
//    }
//}
//interface basicanimal{
//    void eat();
//    void sleep();
//}
//class human extends monkey implements basicanimal{
//    public void  eat(){
//        System.out.println("i am eating...");
//    }
//    public void sleep(){
//        System.out.println("i am sleeping...");
//    }
//
//}
//
//public class chp11_practise {
//    public static void main(String[] args) {
//        fountainpen sc= new fountainpen();
//        sc.hello();
//        sc.refill();
//        sc.write();
//        monkey a=new human();
////        a.eat();
////        a.sleep();
//        a.jump();
//
//
//
//    }
//}

