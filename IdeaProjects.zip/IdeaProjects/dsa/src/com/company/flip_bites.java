package com.company;
// max sum of flipped array
import java.util.Scanner;
public class flip_bites {
    static int flipbits(int[] arr){
        int count=0;

        for(int i=0;i<arr.length;i++){
            if(arr[i]==1){
                count++;
            }
        }
        if(count==arr.length){
            return count;
        }
        for(int i=0;i<arr.length;i++){
            if(arr[i]==0){
                arr[i]=1;
            }
            else{
                arr[i]=-1;
            }
        }
        int maxsum=0;
        int currsum=0;
        int firstidx=0;
        int lastidx=0;
        for(int i=0;i<arr.length;i++){
            currsum+=arr[i];
            if(currsum>=maxsum){
                lastidx=i;
                maxsum=currsum;

            }
            if(currsum<0){

                currsum=0;
                firstidx=i+1;

            }
        }

        if(firstidx!=0){
            for(int i=firstidx-1;i>=0;i--)
            if(arr[i]==-1){
                maxsum++;
            }
            else{
                break;
            }
        }
        if(lastidx!=arr.length-1){
            for(int i=lastidx+1;i<arr.length;i++) {
                if (arr[i] ==-1) {
                    maxsum++;
                }
                else{
                    break;
                }
            }
        }
        for(int i=firstidx;i<=lastidx;i++){

            if(arr[i]==-1){
                maxsum++;
            }
        }
        System.out.println(firstidx);
        System.out.println(lastidx);


        return maxsum;
    }

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
       int limit=sc.nextInt();
       int[] arr= new int[limit];
       for(int i=0;i<arr.length;i++){
           int element=sc.nextInt();
           arr[i]=element;
       }
        System.out.println(flipbits(arr));
    }
}
