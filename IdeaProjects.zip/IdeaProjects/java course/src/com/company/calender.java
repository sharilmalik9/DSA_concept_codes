package com.company;
import java.util.*;
class Result {



    public static String findDay(int month, int day, int year) {
        Calendar cal=Calendar.getInstance();
        cal.set(year,month-1,day);
        int value=cal.get(Calendar.DAY_OF_WEEK);
        String day1=" ";


        switch(value){
            case 7:
                day1="Sunday";
                break;
            case 1:
                day1="Monday";
                break;
            case 2:
                day1="Tuesday";
                break;
            case 3:
                day1="Wednesday";
                break;
            case 4:
                day1="Thursday";
                break;
            case 5:
                day1="Friday";
                break;
            case 6:
                day1="Saturday";
                break;
        }
        return day1.toUpperCase();

    }

}

public class calender {
    public static void main(String[] args)  {
        Scanner sc=new Scanner(System.in);
        int month =sc.nextInt();
        int day=sc.nextInt();
        int year= sc.nextInt();

       Result r= new Result();
//        if(month==2){
//            if(day==29){
//                if (year/4==0){
//                    String sc1=r.findDay(month,day,year);
//                    System.out.println(sc1);
//                }
//
//                else{
//                    System.out.println("not applicable");
//                }
//
//            }
//            else{
//                String sc1=r.findDay(month-1,day,year);
//                System.out.println(sc1);
//
//            }
//        }
        String sc1=r.findDay(month,day,year);
        System.out.println(sc1);




    }
}