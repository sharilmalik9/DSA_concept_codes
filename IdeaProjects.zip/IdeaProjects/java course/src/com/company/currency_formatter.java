package com.company;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.*;


public class currency_formatter {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        double payment=sc.nextDouble();
        Locale indiaLocale = new Locale("en", "IN");// of not predifined use this
        NumberFormat no=NumberFormat.getInstance(Locale.US);
        NumberFormat no1=NumberFormat.getInstance(Locale.CHINA);
        NumberFormat no3=NumberFormat.getInstance(Locale.FRANCE);
        NumberFormat no4=NumberFormat.getInstance(indiaLocale);
        System.out.printf("US: "   +"%36s"  + no.format(payment));
        System.out.println("India: "  + no4.format(payment));
        System.out.println("China: "  + no1.format(payment));
        System.out.println("France: " + no3.format(payment));


    }
}
