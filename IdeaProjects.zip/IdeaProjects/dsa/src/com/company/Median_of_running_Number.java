package com.company;
import java.util.*;
// keep returning median of a stream


public class Median_of_running_Number {
    PriorityQueue<Integer> max= new PriorityQueue<>(Collections.reverseOrder());
    PriorityQueue<Integer> min= new PriorityQueue<>();

    public double findmedian(){
        if(max.size()==min.size()){
            System.out.println(max.peek());
            return (max.peek()/2.0+ min.peek()/2.0);

        }
        return max.peek();

    }
    // creating public methods to access max and min heaps
    public void insert(int element){
        // adding an element smaller than peek wont change median so can add here
        // but if its greater then it should be put in min heap(which will return min element from it
        // but it has elements> media
        if(max.isEmpty()||element<=max.peek()){
            max.add(element);
        }
        else{
            min.add(element);
        }
     //   min.add(element);
        if(max.size()>min.size()+1){
            min.add(max.poll());
        }
        // make sure always max has more no. of elements is equal cant be there
        // ie odd no of elements
        else if(min.size()>max.size()){
            max.add(min.poll());
        }
    }

    public static void main(String[] args) {
        // bcoz public methods cant be accessed in static methods so we have to make object of class used
        Median_of_running_Number obj= new Median_of_running_Number();
        obj.insert(3);
        obj.insert(4);
        obj.insert(1);
        System.out.println(obj.findmedian());
        obj.insert(2);
        System.out.println(obj.findmedian());
      //  obj.insert(6);
      //  System.out.println(obj.findmedian());


    }

}
