package com.company;

public class chp6_practise {
    public static void main(String[] args) {
//        ques 1
//        float sum=0.0f;
//        float [] marks= {10.0f,102.0f,45.07f,34.6f,10.0f};
//        for (int i=0; i<marks.length;i++){
//            System.out.println(marks[i]);
//
//            sum=sum+marks[i];
//            System.out.println(sum);
//        }
//        int [] list= {10,102,45,34,10};
//        int element= 10;
//        for(int i:list){
//            if(element==i){
//                System.out.println("yes");
//                break;
//            }
//        }
// ques 4
//        int[][] array1={{1,2,3},
//                        {4,5,6}};
//        int[][] array2={{7,8,9},
//                        {10,11,12}};
//        int[][] sum={{0,0,0},
//                     {0,0,0}};
//        for(int i=0;i<array1.length;i++){
//            for(int j=0; j<array1[i].length;j++){
//                sum[i][j]=array1[i][j]+ array2[i][j];
//            }
//
//
//        }
//        for(int i=0; i<sum.length;i++){
//                for(int element:sum[i]){
//                System.out.print(element+" ");
//            }
//            System.out.println(" ");
//        }
//        ques 5 reverse an array
//
//        ques 8
        int[] array1={2,5,3,54,12};
        for(int i =0; i<array1.length-1; i++){
            if(array1[i]>array1[i+1]){
                System.out.println("not arranged ");
                break;

            }
        }










        }









    }

