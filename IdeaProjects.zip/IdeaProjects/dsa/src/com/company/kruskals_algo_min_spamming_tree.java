package com.company;
import java.util.*;


class edge implements Comparable<edge>{
    int src,dest,wt;
    edge(int src,int dest,int wt){
        this.src=src;
        this.dest=dest;
        this.wt=wt;
    }
    public int compareTo(edge that){
        return this.wt-that.wt;
    }

}
public class kruskals_algo_min_spamming_tree {
    void disjoint_set(int n ){
        int[] p= new int[n];
    }
    int parent(int[] p,int x){
        if(p[x]==x){
            return x;
        }
        return parent(p,p[x]);
    }
    void union(int a,int b,int[] p){
        int x=parent(p,a);
        int y= parent(p,b);
        if(x==y){
            return;
        }
        p[x]=y;



    }









}
