package com.company;

import java.util.Arrays;
import java.util.Stack;

public class nearest_smallest_element_right_and_left {
    static int[] SmallestElementOnLeft(int[] arr) {
        int [] ans= new int[arr.length];
        Stack<Integer> anshelp= new Stack<>();

        int idx=0;
        for(int i=0;i<arr.length;i++) {
            while (!anshelp.empty() && anshelp.peek() > arr[i]) {
                anshelp.pop();
            }
            if (anshelp.isEmpty()) {
                ans[idx] = -1;
                idx++;
            } else {
                ans[idx] = anshelp.peek();
                idx++;

            }
            anshelp.push(arr[i]);
        }

        return ans;
    }

    static int[] smallestELementOnRight(int[] arr){
        int [] ans= new int[arr.length];
        Stack<Integer> anshelp= new Stack<>();

        int idx=ans.length-1;
        for(int i=arr.length-1;i>=0;i--) {
            while (!anshelp.empty() && anshelp.peek() > arr[i]) {
                anshelp.pop();
            }
            if (anshelp.isEmpty()) {
                ans[idx] = -1;
                idx--;
            } else {

                ans[idx] = anshelp.peek();
                System.out.println(ans[idx]);
                idx--;

            }
            anshelp.push(arr[i]);
        }

        return ans;


    }

    public static void main(String[] args) {
        // it gives elements
        int[] arr={5,6,7,4,5};
        System.out.println(Arrays.toString(SmallestElementOnLeft(arr)));
        System.out.println(Arrays.toString(smallestELementOnRight(arr)));
    }
}
