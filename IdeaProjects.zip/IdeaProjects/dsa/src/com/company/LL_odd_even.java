package com.company;
import java.util.*;
//Given a list, modify it such that all odd elements appear before the even ones.
// The order of odd elements and even shall remain intact.
//Input Format
//The first line contains an integer N, the number of elements in the list.
// The next line contains N space separated integral elements of the list.


public class LL_odd_even {
    // entire code in delete node ll
    }