package com.company;
import java.util.*;
class pair{
    int[] cords;
    double distance;
    public pair(int[] cords) {

        this.cords = cords;

    }
    void dis(int[] cords){
        this.distance=(Math.pow(cords[0],2)*Math.pow(cords[1],2));
    }
    int[] cordsreturn(){
        return this.cords;
    }
}
class paircomparator implements Comparator<pair>{
    public int compare(pair s1, pair s2) {
        if (s1.distance < s2.distance)
            return 1;
        else if (s1.distance > s2.distance)
            return -1;
        return 0;
    }
}

public class k_closest_points_to_origin {
    public static void main(String[] args) {
        int[][] points = {};
        int k=0;
        PriorityQueue<pair> pq = new PriorityQueue<pair>(points[0].length, new paircomparator());
        for (int i = 0; i < points[0].length; i++) {
            pair cordsm=new pair(points[i]);
            pq.add(cordsm);


        }
        int[][] ans= new int[2][points[0].length];
        for(int i=0;i<k;i++){
           ans[i]= pq.peek().cordsreturn();
           pq.poll();


        }
        System.out.println(ans);



    }

}
