package com.company;

import java.util.Arrays;

public class bellmen_ford_algo_negative_cycle {
    // tell if there is negative cycle or not and if not then find the min dist from root element
    static int mindist(int n,int[][] edges){
        int[] dist=new int[n];
        Arrays.fill(dist,Integer.MAX_VALUE);
        dist[0]=0;
        // run this n-1 times
        // edges=[[1,2,-3],[2,3,-4],[3,0,2]]
        // sec dest wt
        for(int i=1;i<n;i++){
            for(int j=0;j<edges.length;j++){
                int src=edges[j][0];
                int dest=edges[j][1];
                int wt=edges[j][2];
                if(dist[src]+wt<dist[dest] &&  dist[src]!=Integer.MAX_VALUE){
                    dist[dest]=dist[src]+wt;
                }

            }

        }
        for(int j=0;j<edges.length;j++){
            int src=edges[j][0];
            int dest=edges[j][1];
            int wt=edges[j][2];
            if(dist[src]+wt<dist[dest] &&  dist[src]!=Integer.MAX_VALUE){
                return 1;
                // again we come in a loop where we are chnaging values so cycle is there
            }

        }
        return 0;


    }
    public static void main(String[] args) {

    }
}
