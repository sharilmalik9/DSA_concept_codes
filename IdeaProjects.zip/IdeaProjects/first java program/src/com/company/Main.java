package com.company;

public class Main {

        public static void main(String[] args) {

            System.out.println("hello world");
            int num1 = 8;
            int num2 = 16;
            int num3 = 4;
            int sum = num1 + num2 + num3;
            System.out.println(sum);
        }
}
