package com.company;
// whenever such ques comes without fixed kind of answer than find answer using range (binary search)

public class Minimum_Limit_of_Balls_in_a_Bag {
    static boolean operations(int[] nums, int maxOperations,int mid){
        int operations=0;
        for(int i=0;i<nums.length;i++){
            if(nums[i]<=2*mid&&nums[i]>mid){
                operations++;
            }
            if(nums[i]>2*mid){
                int element=nums[i];
                while(element>mid){
                    element=element-mid;
                    operations++;
                }
            }
        }
        if(operations<=maxOperations){
            return true;
        }
        else{
            return false;
        }
    }
    static int minLimOfBalls(int[] nums,int maxOperations){
        int min=1;
        int max=0;
        int ans=0;
        for(int i=0;i<nums.length;i++){
            if(nums[i]>max){
                max=nums[i];
            }
        }
        while(min<=max){
            int mid=(min+max)/2;
            if(operations(nums,maxOperations,mid)){
                ans=mid;
                max=mid-1;
            }
            else{
                min=mid+1;
            }
        }
        return ans;
    }
     public static void main(String[] args){
        int[] nums={9};
         System.out.println(minLimOfBalls(nums,2));

     }

}
