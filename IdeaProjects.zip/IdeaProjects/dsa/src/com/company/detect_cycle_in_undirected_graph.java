package com.company;

import java.util.ArrayList;

public class detect_cycle_in_undirected_graph {

    static boolean detectCycle(int v, ArrayList<ArrayList<Integer>> neigh,boolean[] visited,int parent){
        visited[v]=true; // true

        for(Integer i:neigh.get(v)){
            if(!visited[i]){
                if(detectCycle(i,neigh,visited,v)){
                    return true;
                }

            }
            else if(parent!=i){
                return true;

            }
        }
        return false;

    }
    static boolean detectCycleDirectedGraph(int v,ArrayList<ArrayList<Integer>> neigh , boolean[] visited ,boolean[] rec){
        rec[v]=true;
        visited[v]=true;
        for(int i: neigh.get(v)){
            if(!visited[i]){
                detectCycleDirectedGraph(i,neigh,visited,rec);
            }
            else if(rec[i]){
                return true;
            }
        }
        rec[v]=false;
        return false;
    }
    public static void main(String[] args) {
        ArrayList<ArrayList<Integer>> neigh= new ArrayList<>();
       //assumgin v=10
        int v=10;
        boolean ans=false;
        boolean[] visited= new boolean[v];
        for(int i=0;i<v;i++){
            if(!visited[i]) {
                if(detectCycle(i, neigh, visited,-1)){
                    ans=true;
                }
            }


        }


    }


}
