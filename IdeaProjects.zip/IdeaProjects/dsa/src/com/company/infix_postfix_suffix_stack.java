package com.company;

import java.util.Stack;

public class infix_postfix_suffix_stack {
    static int prec(char c){
        int ans =0;
        switch(c){
            case '+':
                ans=1;
                break;
            case '-':
                ans=1;
                break;
            case '*':
                ans=2;
                break;
            case '/':
                ans=2;
                break;
            case'(' :
                ans=0;
                break;
        }
        return ans ;


    }
    static String infixToSuffix(String s){
        Stack<String> help= new Stack<>() ;
        String ans ="";
        for(int i=0; i<s.length();i++){
            System.out.println(ans);
            System.out.println(help);
            if(s.charAt(i)=='('){
                help.push(s.substring(i,i+1));
                continue;

            }

            else if(s.charAt(i)=='+'||s.charAt(i)=='-'||s.charAt(i)=='*'||s.charAt(i)=='/'){
                if(help.isEmpty()){
                    help.push(s.substring(i,i+1));
                    continue;

                }
                else{

                        while (!help.isEmpty() && prec(s.charAt(i))<= prec(help.peek().charAt(0)) ) {
                            ans += help.pop();
                        }
                       help.push(s.substring(i,i+1));


                }
            }
            else if (s.charAt(i)==')'){
                System.out.println("hello");
                while(!help.isEmpty()){
                    System.out.println(help);
                    if(help.peek().charAt(0)=='('){
                        System.out.println("imma");
                        help.pop();
                        break;
                    }
                    else {
                         ans+=help.pop();

                    }
                }

            }

            else{
                ans+=s.charAt(i);
            }

        }

        while(!help.isEmpty()){
            ans+=help.pop();
        }
        return ans;
    }
    static int operator(int os1,int os2,char c){
        switch (c){
            case '+':
                return os1+os2;

            case '-':
                return os1-os2;

            case '*':
                return os1*os2;

            case '/':
                return os1/os2;

        }
        return -1;
    }
    static int suffixToAns(String s){
        int ans =0;
        Stack<Integer> st= new Stack<>();
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)=='+'||s.charAt(i)=='-'||s.charAt(i)=='*'||s.charAt(i)=='/'){
                int os1=st.pop();
                int os2=st.pop();
                st.push(operator(os1,os2,s.charAt(i)));
            }
            else{
                int no=s.charAt(i)-'0';
                st.push(no);
            }
        }
        return st.pop();
    }

    public static void main(String[] args) {
        String s="2+3/3(5*4)-2";
        System.out.println(infixToSuffix(s));
        System.out.println(suffixToAns(infixToSuffix(s)));

    }
}
