package com.company;
import java.util.Scanner;

public class area_of_parralogram {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
       int no=sc.nextInt();
       String str=Integer.toString(no);
        System.out.println("good job");

    }
}
