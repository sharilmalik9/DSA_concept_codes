package com.company;

public class chp1_codes {
    public static void main(String[] args) {

    }
}
