package com.company;
import java.util.Scanner;

public class end_of_file_hr {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        boolean flag=true;
        int i =0;
//        String[] str1=new String[];
        while(sc.hasNext()) {
            i++;
            System.out.println(i + " " + sc.nextLine());



        }

    }

}
