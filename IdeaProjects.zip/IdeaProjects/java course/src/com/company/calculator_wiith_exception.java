package com.company;
import java.util.Scanner;
class myexception1 extends Exception{
    public String toString(){
        return"this is wrong operation";
    }
    public String getMessage(){
        return"this is out of range no";

    }
}

public class calculator_wiith_exception {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("input the numbers you want for operation but less than 10000");
        int no1=sc.nextInt();
        int no2=sc.nextInt();
        System.out.println("press following no for operations");
        System.out.println("1-Addition");
        System.out.println("2- Subtraction");
        System.out.println("3- Multiplication");
        System.out.println("4-Division");
        int operation=sc.nextInt();
        if(no1<10000 && no2<10000) {
            switch (operation) {
                case 1:
                    System.out.println(no1+no2);
                case 2:
                    System.out.println(no1-no2);
                case 3:
                    if(no1<7000 && no2<7000){
                        System.out.println(no1*no2);
                    }
                    else{
                        System.out.println("extended output");
                    }
                case 4 :
                    try{
                        System.out.println(no1/no2);
                    }
                    catch(ArithmeticException e){
                        System.out.println("/ by 0 exception");
                    }
                default:
                    try{
                        throw new myexception1();
                    }
                    catch(Exception e){
                        System.out.println(e.toString());
                    }



            }
        }
        else{
            try{
                throw new myexception1();
            }
            catch(Exception e ){
                System.out.println(e.getMessage());
            }
        }

    }
}
