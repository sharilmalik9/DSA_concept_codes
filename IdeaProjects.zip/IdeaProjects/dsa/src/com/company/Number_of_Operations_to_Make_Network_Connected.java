package com.company;
import java.util.*;

public class Number_of_Operations_to_Make_Network_Connected {
    public  static int makeConnected(int n, int[][] connections) {

        int[][] arr=connections;
        if(arr.length<n-1){
            return -1;
        }

        int m=arr.length;

        ArrayList<ArrayList<Integer>> adj=new ArrayList<>();

        for(int i=0;i<n;i++){
            adj.add(new ArrayList<>());
        }

        for(int i=0;i<m;i++){
            adj.get(arr[i][0]).add(arr[i][1]);
            adj.get(arr[i][1]).add(arr[i][0]);
        }

        int ct=0;
        boolean[] vis=new boolean[n];


        for(int i=0;i<n;i++){
            if(!vis[i]){


                ct++;
                System.out.println(i);
                dfs(adj,i,vis);
            }
        }

        return ct-1;
    }

    public static void dfs(ArrayList<ArrayList<Integer>> adj,int cur, boolean[] vis){
        vis[cur]=true;

        for(int e: adj.get(cur)){
            if(!vis[e]){
                dfs(adj,e,vis);
            }
        }


    }

    public static void main(String[] args) {
        int[][] arr={{0,1},{0,2},{0,3},{1,2},{2,3}};
        System.out.println(makeConnected(6,arr));

    }



}
