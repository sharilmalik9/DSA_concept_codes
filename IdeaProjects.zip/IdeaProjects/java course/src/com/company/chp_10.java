package com.company;
class circle{
    int radius ;
    circle(){
//        super();

        System.out.println("hello i  am joey " + radius);
    }

    public int getX() {
        return radius;
    }

    public void setX(int radius) {
        this.radius = radius;
    }
    public void area(){
        double area= 3.14*(radius*radius);
        System.out.println("area is "+ area);

    }
}
class cylinder extends circle{
    int height;
//    public cylinder(int height ){

//       super();

//        System.out.println("this is monica "+ radius+" "  +height);


//    }

    public int getY() {
        return height;
    }

    public void setY(int height) {
        this.height=height;
    }
    public void area(){
        System.out.println(3.14*radius*height);
    }
}





public class chp_10 {
    public static void main(String[] args) {
        cylinder a = new cylinder();
//        a.monica(2);
//        int x = 2;
        a.setX(2);
        int radius1=a.getX();
        a.area();
        a.setY(3);
        int c = a.getY();
        a.area();


    }
}