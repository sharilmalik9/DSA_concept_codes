package com.company;
 import java.lang.invoke.SwitchPoint;
 import java.util.Scanner;
 import java.util.Random;

public class ch4_practise {
    public static void main(String[] args) {
        Scanner a =new Scanner(System.in);
        System.out.println("0 = stone" );
        System.out.println("1= paper");
        System.out.println("2=scissors ");
        int urchoice= a.nextInt();
        Random rand= new Random();
        int computer= rand.nextInt(3);
        if (urchoice == 0){
            if(computer==0) {
                System.out.println("oops tie ");
            }
            else if (computer==1) {
                System.out.println("computer looses ");
            }
            else if(computer==2){
                System.out.println("u loose ");
            }





        }



    }
}
