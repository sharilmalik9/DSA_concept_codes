package com.company;
// find a subarrayy in an array such that sum of the subarray is max

public class kadanes_theoram {
    static int maxsum(int[] arr){
        int maxsum=0;
        int currsum=0;
        for(int i=0; i<arr.length;i++){
            currsum+=arr[i];
            if(currsum>maxsum){
                maxsum=currsum;
            }
            if(currsum<0){
                currsum=0;
            }
        }
        return maxsum;

    }

    public static void main(String[] args) {
        int[] arr={2,3,-10,30,-5,6,7};
        System.out.println(maxsum(arr));

    }
}
