package com.company;
// shortest code out there for this

import java.util.Arrays;

public class array_remove_duplicates_from_sorted {
    public static void main(String[] args) {
        int[] arr1={1,1,2,2,2,4,5,6};
        int current=arr1[0];
            for(int j=1;j<arr1.length;j++) {
                if (arr1[j] == current) {
                    arr1[j] = 0;
                }
                else{
                    current=arr1[j];
                }
            }
        System.out.println(Arrays.toString(arr1));
            // replaced duplicates with 0 now u can easily count doubles









    }
}
