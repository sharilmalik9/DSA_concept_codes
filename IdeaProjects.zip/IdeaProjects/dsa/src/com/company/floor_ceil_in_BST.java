package com.company;

public class floor_ceil_in_BST {
    class Node{
        int data;
        Node right,left;
    }
    static int ceilvalue(Node root,int val){
        int ans =Integer.MAX_VALUE;
        while(root!=null){
            if(root.data==val){
                return root.data;
            }
            if(root.data<val){
                root=root.right;
            }
            else{
                ans=root.data;
                root=root.left;
            }
        }
        return ans;
    }
    static int floor(Node root,int val){
        int ans= Integer.MIN_VALUE;
        while(root!=null){
            if(root.data==val){
                return root.data;
            }
            if(root.data<val){
                ans=root.data;
                root=root.right;
            }
            else{

                root=root.left;
            }

        }
        return ans;
    }

}
