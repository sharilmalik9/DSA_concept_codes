package com.company;

public class Longest_Substring_with_atmost_k_distinct_characters {
    public static void main(String[] args) {


    }
}
