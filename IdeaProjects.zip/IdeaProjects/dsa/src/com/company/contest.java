package com.company;
import java.util.*;

public class contest {

    public static void main(String[] args) {


        Scanner scn = new Scanner(System.in);

        int t = scn.nextInt();


        while (t > 0) {
            int x =scn.nextInt();
            int y = scn.nextInt();
            int ans =0;
           if(x%2==0 && y%2==0){
               ans=0;
           }
           else if(x%2==0 && y%2!=0){
               ans=x;

           }
           else if(x%2!=0 && y%2==0) {
               ans = y;
           }
           else{
               ans=x+y-1;
           }


            System.out.println(ans);



           t--;
        }

    }
}

