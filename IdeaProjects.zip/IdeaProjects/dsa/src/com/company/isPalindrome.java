package com.company;

import java.util.ArrayList;
import java.util.List;

public class isPalindrome
{
    public static  boolean ispalin(List<Integer> ans){
        if(ans.size()==0){
            return true;
        }
        if(ans.size()==1){
            return true;
        }
        boolean palin = true;
        int  i= 0;
//        for(int i=0;i<ans.size()/2;i++){
            System.out.println(ans.get(i));
            System.out.println(ans.get(ans.size()-i-1));
            System.out.println(ans.get(i).equals(ans.get(ans.size()-i-1)));
//            if(ans.get(i)!=ans.get(ans.size()-i-1)){
                System.out.println("Hello");
                palin = false;
//                return false;
//            }
//        }

        return palin;

    }

    public static void main(String[] args) {


        List<Integer> ans = new ArrayList<>();
        int  i= 0;

        ans.add(2);
        ans.add(3);
        ans.add(3);
        ans.add(2);
        System.out.println(ans.get(i));
        System.out.println(ans.get(ans.size()-i-1));
        System.out.println(ans.get(i)==ans.get(ans.size()-i-1));
      System.out.println(1001==1001);

    }


}
