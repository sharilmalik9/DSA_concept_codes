package com.company;
// nlogn
// binary search using

import java.util.Arrays;

public class Find_First_and_Last_Position_of_Element_in_Sorted_Array {
    static int[] position(int[] nums,int target){
        int[] ans={-1,-1};
        int start=0;
        int end=nums.length-1;
        int first=-1;
        int last=-1;
        int i=0;
        while(start<=end){
            int mid=(start+end)/2;
            if(nums[mid]<target){
                start=mid+1;
            }
            if(nums[mid]>target){
                end=mid-1;

            }
            if(nums[mid]==target){
                for( i=start;i<=mid;i++){
                    if(nums[i]==target){
                        first=i;
                        break;
                    }
                }
                for(i=end;i>=mid;i--){
                    if(nums[i]==target){
                        last=i;
                        break;

                    }
                }
                ans[0]=first;
                ans[1]=last;
                return ans;



            }
        }

        return ans;

    }
    public static void main(String[] args) {
        int[] nums={};
        System.out.println(Arrays.toString(position(nums,6)));

    }
}
