package com.company;
import java.util.*;

public class subarray_sum_equal_k {
    // for valus>1
    public static int subarraySum(int[] nums, int k) {

        int start=0;
        int end=0;
        int count=0;
        int sum=0;
        if(k==0){
            return 0;
        }
        else{
            sum=nums[start];
        }
        while(end<nums.length && start<=end){
            System.out.println(sum);

            if(sum<k){
                end++;
                System.out.println("huh");
            }
            else if(sum==k){
                System.out.println(start +" " +end);
                count++;
                start++;
                end=start;
                sum=0;
                System.out.println("heh");

            }
            else if(sum>k){
                sum=sum-nums[start];
                System.out.println("huii  " + sum );
                start++;
                System.out.println("hola");
                if(end<start){
                    end=start;
                    sum+=nums[end];
                }
                continue;

            }
            if(end<nums.length) {
               // System.out.print("noww  ");
             //   System.out.println(sum);
                sum += nums[end];
                System.out.print("noww  ");
                System.out.println(sum);

            }
            else{
                break;
            }
        }
        return count;
    }
    public int subarraySum1(int[] nums, int k) {
        int res = 0;
        int currSum = 0;
        Map<Integer,Integer> mp = new HashMap<>();
        mp.put(0,1);

        for(int i : nums) {
            currSum += i;
            int diff = currSum - k;
            //this statement should be there no ans++ else few test cases wont work
            res += mp.getOrDefault(diff,0);
            mp.put(currSum,mp.getOrDefault(currSum,0) + 1);
        }
        return res;
    }

    public static void main(String[] args) {
        int[] arr={1,2,3};
        System.out.println(subarraySum(arr,3));
    }
}
