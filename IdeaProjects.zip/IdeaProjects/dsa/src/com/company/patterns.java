package com.company;

public class patterns {
    public static void main(String[] args) {
        int x=0;
        int y=0;
        for(int i=1;i<6;i++){
            for(int j=0;j<i;j++){
                System.out.print(" * ");
            }
            System.out.println();

        }
        System.out.println("--------------------------------------------");
        for(int i=1;i<6;i++){
            for(int j=6;j>=i+2;j--){
                System.out.print("\t");
            }
            for(int j=0;j<i;j++){
                System.out.print("*\t");
               // System.out.print(" ");
            }

            System.out.println();

        }
        System.out.println("------------------------------------------------");
        for(int i=1;i<6;i++){
            for(int j=0;j<i-1;j++){
                System.out.print("\t");
            }


            for(int j=6;j>i;j--){
                System.out.print("*\t");
                // System.out.print(" ");
            }


            System.out.println();

        }
        System.out.println("---------------------------------------------");
      // pattern 5
        for(int i=1;i<5;i++) {
            for (int j = 3; j >= i; j--) {
                System.out.print("\t");

            }
            for (int j = 0; j <i; j++) {
                System.out.print("\t*\t");

            }

            System.out.println();
        }
        System.out.println("*\t\t*\t\t*\t\t*\t\t*");

        for(int i=0;i<5;i++) {
            for (int j = 0; j< i; j++) {
                System.out.print("\t");

            }
            for (int j =5; j>i+1; j--) {
                System.out.print("\t*\t");

            }

            System.out.println();
        }
        System.out.println("---------------------------------------------------------");
        for(int i=0;i<3;i++){
            for(int j=3;j>=0;j--){
                System.out.print("\t");
            }
            for(int j=i; j<2*i+1;j++){
                System.out.print(j+1);
            }
            System.out.println();

        }



    }
}
