package com.company;
import java.util.Scanner;
class myexception extends Exception{
    public String toString(){
        return"you are over ";
    }
}

public class exception_practise {
    public static void main(String[] args) {
        // ques 2
        try{
            System.out.println(5/0);
        }
        catch(ArithmeticException e ){
            System.out.println("haha");

        }
        catch(IllegalArgumentException e){
            System.out.println("hehe");
        }
        // ques 3
        Scanner sc=new Scanner(System.in);
        int[] series= new int[3];
        series[0]=1;
        series[1]=2;
        series[2]=3;
        System.out.println("enter the no of times u want to input ");
        int times=sc.nextInt();
        int i =0;


        boolean flag= true;
        while(flag && i<times){
            int index=sc.nextInt();
            try{
                System.out.println(series[index]+"this is the no");
                flag=false;

            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.println("sorry out of range please retype");
                i++;


            }


        }
        if(i>=times){
            try{
                throw new myexception();
            }
            catch(Exception e){
                System.out.println(e.toString());

            }
        }

        //ques 4





    }
}
