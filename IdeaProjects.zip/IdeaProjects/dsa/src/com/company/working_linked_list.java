package com.company;
import java.util.*;

public class working_linked_list {
    public static void main(String[] args) {
//        linked_list_basic_functions ll= new linked_list_basic_functions();
//        ll.addfirst(10);
//        ll.addlast(20);
//        ll.addlast(30);
//        ll.addlast(40);
//      //  ll.addlast(50);
//        ll.display();
//
//
//        ll.Rev();
//        ll.display();
//        ll.mid();
    }
}
