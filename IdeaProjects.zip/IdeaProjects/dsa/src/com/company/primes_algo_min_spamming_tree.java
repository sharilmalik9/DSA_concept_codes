package com.company;
import java.util.*;

public class primes_algo_min_spamming_tree {
    static class pair implements Comparable<pair>{
        int v;
        int wt;
        pair(int v,int wt){
            this.v=v;
            this.wt=wt;

        }

        @Override
        public int compareTo(pair o) {
            return this.wt-o.wt;
        }
    }
    static int minSpammingTree(List<List<List<Integer>>> neigh, int v){
        boolean[] visited = new boolean[v];
        PriorityQueue<pair> pq= new PriorityQueue<>();
        // add any element

        pq.add(new pair(0,0));
        int ans=0;
        while(!pq.isEmpty()){
            pair cur=pq.poll();
            int u=cur.v;
            if(visited[v]){
                continue;
            }
            ans+=cur.wt;

            for(List<Integer> i: neigh.get(u)){
                int vertex=i.get(0);
                int weight=i.get(1);
                if(!visited[vertex]){
                   pq.add(new pair(vertex,weight));

                }

            }
        }
        return ans;
    }
}
