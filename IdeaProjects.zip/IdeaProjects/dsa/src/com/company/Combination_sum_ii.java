package com.company;
import java.util.*;

public class Combination_sum_ii {
    public static List<List<Integer>> combinationSum2(int[] candidates, int target) {
        List<List<Integer>> hey= new ArrayList<>();
     //   Collections.sort(List.of(candidates));
        List<Integer> small=new ArrayList<>();
        System.out.println("calling");

        combinationSum(candidates,target,target,0,hey,small);
        return hey;

    }
    public static void combinationSum(int[] candidates, int target,int rem , int index,List<List<Integer>> hey,List<Integer> small){
       if(rem==0){
           hey.add(small);
       }
       for(int i=index;i<candidates.length;i++){

       }
    }

    public static void main(String[] args) {
        int[] candidates={1,2,3};
        System.out.println(combinationSum2(candidates,3));


    }
}
