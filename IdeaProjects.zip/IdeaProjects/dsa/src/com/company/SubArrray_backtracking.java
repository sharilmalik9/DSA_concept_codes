package com.company;
import java.util.*;
// err to be rectified

public class SubArrray_backtracking {
     static  List<List<Integer>> ans = new ArrayList<>();
    static void Util(int[] arr,int idx,List<Integer> curr){
        if(idx==arr.length){
            ans.add(curr);
            return;

        }
        System.out.println(curr);
        for(int i=0;i<arr.length;i++){
            curr.add(arr[idx]);
            Util(arr,idx+1,curr);
            // Util(arr,idx,curr);
            curr.remove(curr.size()-1);

        }


    }

    public static void main(String[] args) {
        int[] arr= {1,2,3,0};
        List<Integer> curr = new ArrayList<>();
        Util(arr,0,curr);
        System.out.println(ans);
    }
}
