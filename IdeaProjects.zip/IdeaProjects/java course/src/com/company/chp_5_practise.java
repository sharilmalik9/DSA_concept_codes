package com.company;
import java.util.Scanner;

public class chp_5_practise {
    public static void main(String[] args) {
//        ques 1
        Scanner a = new Scanner(System.in);
//        for(int i=5; i>0;i--){
//            for(int j=0;j<i;j++) {
//                System.out.print("*");
//            }
//            System.out.println("\n");
//        }
//        ques 5


//







    }
}
