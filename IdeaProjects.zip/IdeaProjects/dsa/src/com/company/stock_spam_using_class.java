package com.company;

import java.util.ArrayList;
import java.util.Stack;

public class stock_spam_using_class {
        ArrayList<Integer> arr= new ArrayList<>();
        public stock_spam_using_class(){


        }
        public int next(int price){
            arr.add(price);
            return stockSpam(arr);
        }
        static int stockSpam(ArrayList<Integer> arr){
            int[] ans= new int[arr.size()];
            Stack<Integer> help= new Stack<>();
            if(arr.size()==0){
                return 0;
            }

            help.push(0);
            for(int i=arr.size()-1;i>=0;i++){
                while(!help.isEmpty()&&arr.get(help.peek())<arr.get(i)){
                    ans[help.peek()]=i-help.pop();
                }
                help.add(i);

            }
            while(!help.isEmpty()){
                ans[help.pop()]=0;
            }
            return ans[ans.length-1];

        }



}
