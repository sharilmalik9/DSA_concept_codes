package com.company;

import java.util.Stack;

public class paranthesis_matching_problem {
    static boolean paranthesis(String s){
        Stack<String>  ans = new Stack<>();
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)=='{'){
                ans.push(s.substring(i,i+1));
            }
            else{
                if(ans.isEmpty()){
                    return false;
                }
                else{
                    ans.pop();
                }
            }

        }
        if(ans.isEmpty()){
            return true;
        }
        else{
            return false;
        }

    }

    public static void main(String[] args) {
        String str="{}}}}{{{";
        System.out.println(paranthesis(str));
    }
}
